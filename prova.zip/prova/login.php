<?php
    if ( !isset($_POST["username"]) || !isset($_POST["password"]) ){
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
</head>
<body>
    <form action="login.php" method="post">
        <label for="username">Username:</label><br>
        <input type="text" name="username" required><br>
        <label for="password">Password:</label><br>
        <input type="password" name="password" required><br><br>
        <input type="submit" value="Login">
    </form>
	Non sei ancora registrato? &nbsp; <a href="http://localhost/CortiVerifica/register.php">Registrati</a>
</body>
</html>
<?php
}else{
    $username=$_POST["username"];
    $password=$_POST["password"];
    //echo "username= ".$username."<br>";
    //echo "password= ".$password."<br>";
    //CONNESSIONE AL DB
    $DBhost="localhost";
    $DBusername="root";
    $DBpassword="";
    $DBname="utenti";
    $connection=new mysqli($DBhost,$DBusername,$DBpassword,$DBname);
    if ($connection->connect_error) {
        die("Errore connessione!");
      }
    
    //Controllo sel lo username è presente nel db
	$query="SELECT * FROM users WHERE username=?";
	$statement=$connection->prepare($query);
    $statement->bind_param("s",$username);
    $statement->execute();
	
	$user_row= $statement->get_result()->fetch_array();
	
	if($user_row!=0){
		
		
		if($user_row["password"]===substr(crypt($password,"st"),0,10)){
			echo "Password corretta!<br>";
			
			//Distruggo eventuale sessione esistente
			echo session_start();
			session_unset(); //libera le variabili di sessione
			session_destroy();
			
			//Inizializzo nuova sessione
			session_start();
			$_SESSION["username"]=$username;
			$_SESSION["start_time"]=time();
			
					
			
		}else{
			echo "Password errata!<br>";
			echo "<a href=\"http://localhost/CortiVerifica/login.php\">Riprova</a>";
		}
		 
		 
		 
		
	}
		
		
	  //Cifratura della password
	  $password=crypt($password,"st");
	  


      header('Location:http://localhost/CortiVerifica/index.php');


      //INSERIMENTO DATI NEL DB CON PREPARED STATEMENT
      $query="INSERT INTO users (username,password) VALUES(?,?)";
      $statement=$connection->prepare($query);
      $statement->bind_param("ss",$username,$password);
      $statement->execute();

      $connection->close();


}
?>