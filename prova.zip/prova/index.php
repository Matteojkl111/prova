<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Verifica</title>
    </head>
    <body>
	<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagina di Prova</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        header {
            background-color: #333;
            color: white;
            padding: 1em 0;
            text-align: center;
        }
        nav {
            display: flex;
            justify-content: center;
            background-color: #444;
        }
        nav a {
            color: white;
            padding: 1em;
            text-decoration: none;
        }
        nav a:hover {
            background-color: #555;
        }
        main {
            padding: 2em;
        }
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 1em 0;
            position: fixed;
            width: 100%;
            bottom: 0;
        }
    </style>
</head>
<body>
    <header>
        <h1>Benvenuti alla Pagina di Prova</h1>
    </header>
    <nav>
        <a href="#home">Home</a>
        <a href="#about">Chi siamo</a>
        <a href="#services">Servizi</a>
        <a href="#contact">Contatti</a>
    </nav>
    <main>
        <section id="home">
            <h2>Home</h2>
            <p>Questa è la sezione home della pagina di prova.</p>
        </section>
        <section id="about">
            <h2>Chi siamo</h2>
            <p>Questa è la sezione "Chi siamo" della pagina di prova.</p>
        </section>
        <section id="services">
            <h2>Servizi</h2>
            <p>Questa è la sezione servizi della pagina di prova.</p>
        </section>
        <section id="contact">
            <h2>Contatti</h2>
            <p>Questa è la sezione contatti della pagina di prova.</p>
        </section>
    </main>
    <footer>
        <p>&copy; 2024 Pagina di Prova. Tutti i diritti riservati.</p>
    </footer>
</body>
</html>

        <?php
        $barca=array();
        
        $DBhost="localhost";
        $DBusername="root";
        $DBpassword="";
        $DBname="utenti";
        $connection=new mysqli($DBhost,$DBusername,$DBpassword,$DBname);
        if ($connection->connect_error) {
            die("Errore connessione!");
        }
        
        $queryArrBarca = "SELECT DISTINCT * FROM `barche`;";
        $result=$connection->query($queryArrBarca);
        
        $BarcheUscite=array();
        s
        echo "<a href=\"http://localhost/CortiVerifica/logout.php\">Esci</a>"."<br>";
        echo "<a href=\"http://localhost/CortiVerifica/nuovabarca.php\">Nuova</a>"."<br>";
        echo "<a href=\"http://localhost/CortiVerifica/eliminabarca.php\">Elimina</a>";
        
       
        
       
        $connection->close();
        
        ?>
    </body>
</html>
