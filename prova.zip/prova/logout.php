<?php
	
	//distruggo la sessione corrente
	session_start();
	session_unset(); //libera le variabili di sessione
	session_destroy();
	

?>

<html lang="en">
<head>
    <title>logout</title>
</head>
<body>
    Sessione scaduta: &nbsp; <a href="http://localhost/CortiVerifica/login.php">Login</a>
	
</body>
</html>