<?php
    if ( !isset($_POST["username"]) || !isset($_POST["password"]) ){
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Register</title>
</head>
<body>
    <form action="register.php" method="post">
        <label for="username">Username:</label><br>
        <input type="text" name="username" required><br>
        <label for="password">Password:</label><br>
        <input type="password" name="password" required><br><br>
        <input type="submit" value="Register">
    </form>
</body>
</html>
<?php
}else{
    $username=$_POST["username"];
    $password=$_POST["password"];
    echo "username= ".$username."<br>";
    echo "password= ".$password."<br>";
    //CONNESSIONE AL DB
    $DBhost="localhost";
    $DBusername="root";
    $DBpassword="";
    $DBname="utenti";
    $connection=new mysqli($DBhost,$DBusername,$DBpassword,$DBname);
    if ($connection->connect_error) {
        die("Errore connessione!");
      }
	
	//Controllo sel lo username è presente nel db
	$query="SELECT * FROM users WHERE username=?";
	$statement=$connection->prepare($query);
    $statement->bind_param("s",$username);
	
    $statement->execute();
	
	
	if($statement->get_result()->fetch_array()!=0){
		
		echo "Utente $username presente nel DB<br>";
		echo "<a href=\"http://localhost/CortiVerifica/login.php\">Login</a>";
		
	}else{
		
      $statement->free_result();
	  //Cifratura della password
	  $password=crypt($password,"st");
	  
      //INSERIMENTO DATI NEL DB CON PREPARED STATEMENT
      $query="INSERT INTO users (username,password) VALUES(?,?)";
      $statement=$connection->prepare($query);
      $statement->bind_param("ss",$username,$password);
      $statement->execute();
		
	  
      header('Location:http://localhost/CortiVerifica/login.php');
	}
	$statement->free_result();
	$connection->close();
}
?>